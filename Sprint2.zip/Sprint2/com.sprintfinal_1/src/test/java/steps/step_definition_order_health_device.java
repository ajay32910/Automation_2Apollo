package steps;

import java.io.IOException;
import java.lang.StackWalker.Option;
import java.util.concurrent.TimeUnit;

import org.openqa.selenium.JavascriptExecutor;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.chrome.ChromeDriver;
import org.openqa.selenium.chrome.ChromeOptions;

import cucumber.api.java.Before;
import cucumber.api.java.en.Given;
import cucumber.api.java.en.Then;
import cucumber.api.java.en.When;

public class step_definition_order_health_device {
	ChromeOptions options = new ChromeOptions();
	

	WebDriver driver;
	String path="C:\\seleniumFiles\\chromedriver.exe";
	String web_p="https://www.apollopharmacy.in/";
	OrderHealthdevice_pagefactory obj;

	@Before
	public void start_browser()
	{
		options.addArguments("--disable-notifications");
		System.setProperty("webdriver.chrome.driver",path);
		driver=new ChromeDriver(options);
		driver.manage().window().maximize();
		obj=new OrderHealthdevice_pagefactory(driver);
		driver.manage().timeouts().implicitlyWait(10, TimeUnit.SECONDS);
	}


	@Given("user navigate to Home page")
	public void user_navigate_to_Home_page() throws Exception {
	    driver.get(web_p);
	    obj.selectpin();
		//Thread.sleep(9000);
		

		//System.out.println("Given ");
		}

	@When("user hover cursor on health device tab")
	public void user_hover_cursor_on_health_device_tab() {
	    // Write code here that turns the phrase above 
		obj=new OrderHealthdevice_pagefactory(driver);
		obj.hover();
		//obj.healthAccessories();
		
	    
	}

	@Then("list of category should display")
	public void list_of_category_should_display() {
	    // Write code here that turns the phrase above into concrete actions
		System.out.println("list is displayed");
		
	    
	}
	@Then("close")
	public void close() throws InterruptedException {
		Thread.sleep(5000);
		System.out.println("Closing the Browser");
		driver.close();
	}

	@Given("user go to Home page")
	public void user_go_to_Home_page() throws Exception {
	    // Write code here that turns the phrase above into concrete actions
		driver.get(web_p);
		obj.selectpin();
		//Thread.sleep(9000);
	   // throw new cucumber.api.PendingException();
	}
	@When("user hover cursor on health tab")
	public void user_hover_cursor_on_health_tab() {
    // Write code here that turns the phrase above into concrete actions
		obj.hover();
		//throw new cucumber.api.PendingException();
	}


	@Then("list of category display")
	public void list_of_category_display() {
	    // Write code here that turns the phrase above into concrete actions
		System.out.println("list displayed");
	    //throw new cucumber.api.PendingException();
	}

	@When("user click to requried category")
	public void user_click_to_requried_category() {
	    // Write code here that turns the phrase above into concrete actions
		obj.healthAccessories();
	    //throw new cucumber.api.PendingException();
	}

	@Then("user should navigate to product page")
	public void user_should_navigate_to_product_page() {
	    // Write code here that turns the phrase above into concrete actions
		
		System.out.println("user navigated to product page");
	    //throw new cucumber.api.PendingException();
	}


	@When("user hover cursor on product")
	public void user_hover_cursor_on_product() throws Exception {
	    // Write code here that turns the phrase above into concrete actions
		Thread.sleep(3000);
		obj.clickOnProduct();
		Thread.sleep(2000);
		obj.zoomin();
		Thread.sleep(2000);
		obj.clickbutton();
		Thread.sleep(3000);
		obj.zoomin();
		Thread.sleep(3000);
		obj.clickbutton();
		Thread.sleep(3000);
		obj.zoomin();
		Thread.sleep(3000);


		
		
	    
	}

	@Then("product image should zoom in\\/zoom out")
	public void product_image_should_zoom_in_zoom_out() {
	    // Write code here that turns the phrase above into concrete actions
	   System.out.println("image is zoomed in");
	}


	@When("user click on Add to cart button")
	public void user_click_on_Add_to_cart_button() throws Exception {
	    // Write code here that turns the phrase above into concrete actions
		Thread.sleep(3000);
		obj.addtocart();
	    
	}

	@Then("product should add to cart")
	public void product_should_add_to_cart() {
	    // Write code here that turns the phrase above into concrete actions
		System.out.println("product added to cart");
	    
	}
	

	@Given("user navigate to prodcut page")
	public void user_navigate_to_prodcut_page() throws Exception {
	    // Write code here that turns the phrase above into concrete actions
		driver.get(web_p);
		obj.selectpin();
		//Thread.sleep(8000);
		obj.health();   
	}

	@When("user click add to cart button")
	public void user_click_add_to_cart_button() throws Exception {
	    // Write code here that turns the phrase above into concrete actions
		Thread.sleep(2000);
		JavascriptExecutor js = (JavascriptExecutor) driver;
		js.executeScript("window.scrollBy(0,350)", "");
	    obj.addtocart();
	}

	@Then("produt should add to cart and increment button should appear")
	public void produt_should_add_to_cart_and_increment_button_should_appear() {
	    // Write code here that turns the phrase above into concrete actions
	   System.out.println("increment button appeared");
	}
	@When("user click on increament button")
	public void user_click_on_increament_button() throws Exception {
	    // Write code here that turns the phrase above into concrete actions
		
		for(int i=1;i<=4;i++)
		{
			Thread.sleep(1000);
			obj.clickpluse();
		}
		for(int i=1;i<=4;i++)
		{
			Thread.sleep(1000);
			obj.clickminus();
		

		}
		Thread.sleep(2000);
	}

	@Then("number of product should increment in cart")
	public void number_of_product_should_increment_in_cart() throws IOException, InterruptedException {
	    // Write code here that turns the phrase above into concrete actions
	    System.out.println("number of item increased");   
	    System.out.println("number of item decreased");
	    obj.snapshot();
	    Thread.sleep(2000);
	}

	

	

	@When("user click on increament button  and keep on incrementing")
	public void user_click_on_increament_button_and_keep_on_incrementing() throws Exception {
	    // Write code here that turns the phrase above into concrete actions
		for(int i=1;i<=15;i++)
		{
			Thread.sleep(1000);
			obj.clickpluse();
		}
	    
	}

	@Then("user should not allowed to add more than {int} item")
	public void user_should_not_allowed_to_add_more_than_item(Integer int1) {	    
		System.out.println("user is not allowed to add more than"+" "+int1 +" item");
		}
	@When("user click on {string}")
	public void user_click_on(String string) {
	    // Write code here that turns the phrase above into concrete actions
	    obj.GoToCart();
	    System.out.println(string);
	}

	@Then("user should naviagte to cart page")
	public void user_should_naviagte_to_cart_page() {
	    // Write code here that turns the phrase above into concrete actions
	    System.out.println("user navigated to cart page");
	}
	@When("user enter input in {int} and {int} field")
	public void user_enter_input_in_and_field(Integer int1, Integer int2) throws Exception {
	    // Write code here that turns the phrase above into concrete actions
		String s1=String.valueOf(int1);
		String s2=String.valueOf(int2);
		obj.SetPrice(s1, s2);


	}

	@Then("filter should applied")
	public void filter_should_applied() {
	    // Write code here that turns the phrase above into concrete actions
		if(obj.filter.isEnabled())
		{	
			System.out.println("filter applied successfully");
		}
	}
	@Then("filter  should not apply")
	public void filter_should_not_apply() {
		if(obj.filter.isEnabled())
		{	
			System.out.println("filter applied successfully");
		}
		else
		{
			System.out.println("filter button is disabled");
			try {
			System.out.println(obj.error_msg.getText());
			}
			catch(Exception e)
			{
				System.out.println("");
			}
		}
	    
	}
	@When("user enter discount value")
	public void user_enter_discount_value() throws Exception {
	    // Write code here that turns the phrase above into concrete actions
	    obj.setDiscount();
	}

	@Then("click sortBy button")
	public void click_sortBy_button() {
	    // Write code here that turns the phrase above into concrete actions
	   System.out.println("filter applied");
	}


	}
