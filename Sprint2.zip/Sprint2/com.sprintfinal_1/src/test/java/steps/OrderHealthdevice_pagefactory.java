package steps;

import java.io.File;
import java.io.IOException;
import java.util.List;

import org.apache.commons.io.FileUtils;
import org.openqa.selenium.OutputType;
import org.openqa.selenium.TakesScreenshot;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.interactions.Action;
import org.openqa.selenium.interactions.Actions;
import org.openqa.selenium.support.FindBy;
import org.openqa.selenium.support.PageFactory;

public class OrderHealthdevice_pagefactory {
	
	WebDriver driver;
	@FindBy(xpath="//*[@id=\"__next\"]/div/div[1]/div[2]/ul/li[2]/span/a")
		WebElement health;
	@FindBy(xpath="//*[@id=\"__next\"]/div[1]/div[1]/div[2]/ul/li[2]/div/div[2]/div[3]/span/h3/a")
		WebElement health_1;
	@FindBy(xpath="//*[@id=\"__next\"]/div[1]/div[1]/div[2]/ul/li[2]/div/div[2]/div[3]/span/ul/li[1]/a")
		List<WebElement> links;
	@FindBy(xpath="//*[@id=\"__next\"]/div/div[2]/div/div[4]/div[2]/div/div/div[1]/div/div[1]/a/div[2]")
	 	WebElement product;
	@FindBy(xpath="//*[@id=\"__next\"]/div/div[1]/div/div[3]/div/div[3]/div/div[1]/div[1]/div[1]/div/div/div/div[2]/div[1]/div")
		WebElement zoom_image;
	@FindBy(xpath="//*[@id=\"__next\"]/div/div[1]/div/div[3]/div/div[3]/div/div[1]/div[1]/div[1]/div/div/div/div[2]/button[2]")
		WebElement button;
	@FindBy(xpath="//*[@id=\"__next\"]/div/div[2]/div/div[4]/div[2]/div/div[1]/div[1]/div/div[2]/button/span[1]")
		WebElement addtocart;
	@FindBy(xpath="//*[@id=\'__next\']/div/div[2]/div/div[4]/div[2]/div/div[1]/div[1]/div/div[2]/div[3]/button[2]")
		WebElement pluse;
	@FindBy(xpath="//*[@id=\"__next\"]/div/div[2]/div/div[4]/div[2]/div/div[1]/div[1]/div/div[2]/div[3]/button[1]")
		WebElement minus;
	@FindBy(className="jss269")
		WebElement GoToCart;
	@FindBy(xpath="//*[@id=\"__next\"]/div/div[2]/div/div[4]/div[1]/div[1]/div[2]/div[1]/div/div[2]/div[2]/div/div[1]/div/div/input")
		WebElement From_price;
	@FindBy(xpath="//*[@id=\"__next\"]/div/div[2]/div/div[4]/div[1]/div[1]/div[2]/div[1]/div/div[2]/div[2]/div/div[2]/div/div/input")
		WebElement To_price;
	@FindBy(xpath="//*[@id=\"__next\"]/div/div[2]/div/div[4]/div[1]/div[2]/button")
		WebElement filter;
	@FindBy(xpath="//*[@id=\"__next\"]/div/div[2]/div/div[4]/div[1]/div[1]/div[2]/div[1]/div/div[2]/span")
		WebElement error_msg;
	@FindBy(xpath="(//INPUT[@type='number'])[1]")
		WebElement dis_from;
	@FindBy(xpath="//*[@id=\"menu-\"]/div[3]/ul/li[1]")
		WebElement list;
	@FindBy(xpath="//DIV[@class='MuiSelect-root jss125 MuiSelect-select MuiSelect-selectMenu jss126 MuiInputBase-input MuiInput-input']")
		WebElement sort;
	@FindBy(xpath="//*[@id=\"__next\"]/div[1]/div[1]/div[1]/div/header/div[1]/div/div/div")
		WebElement pin;
	

	public OrderHealthdevice_pagefactory(WebDriver p_driver)
	{
		this.driver=p_driver;
		PageFactory.initElements(driver,this);
	}
	public void hover()
	{
		Actions action=new Actions(driver);
		action.moveToElement(health).build().perform();
		
		
	 
	}
//	public void print_list()
//	{
//		for(WebElement x:links)
//		{
//			System.out.println(x.getText());
//		}
//
//	}
	public void healthAccessories()
	{
		health_1.click();
	}
	public void clickOnProduct()
	{
		product.click();
	}
	public void zoomin()
	{
		Actions action=new Actions(driver);
		action.moveToElement(zoom_image).build().perform();
	}
	public void clickbutton() {
		button.click();
	}
	public void addtocart()
	{
		addtocart.click();
	}
	public void health()
	{
		health.click();
	}
	public void clickpluse()
	{
		pluse.click();
	}
	public void clickminus()
	{
		minus.click();
	}
	public void GoToCart()
	{
		GoToCart.click();
	}
	public void SetPrice(String from,String to) throws Exception
	{
		From_price.click();
		Thread.sleep(2000);
		From_price.sendKeys(from);
		To_price.click();
		Thread.sleep(2000);
		To_price.sendKeys(to);
		if(filter.isEnabled())
		{	
			filter.click();
		}
		
	}
	public void setDiscount() throws Exception
	{
		dis_from.click();
		dis_from.sendKeys("10");
		sort.click();
		Thread.sleep(2000);
		list.click();
		filter.click();
	}
	public void selectpin()
	{
		pin.click();
	}
	public void snapshot() throws IOException {
		 
        TakesScreenshot ts=(TakesScreenshot)driver;

        File source=ts.getScreenshotAs(OutputType.FILE);


       FileUtils.copyFile(source, new File(System.getProperty("usr.dir")+"/Screenshot/"+System.currentTimeMillis()+".png"));

        System.out.println("screenshot is taken");


       }

}